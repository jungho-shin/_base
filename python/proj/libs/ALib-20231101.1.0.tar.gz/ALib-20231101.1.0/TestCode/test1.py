
import time


def main():
    start_time = time.time()

    end_time = time.time()

    execution_time = end_time - start_time

    print(f"run t {execution_time}")

    pass


if __name__ == '__main__':
    main()