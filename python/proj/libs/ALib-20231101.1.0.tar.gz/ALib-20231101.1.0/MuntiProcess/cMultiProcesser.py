import math
import multiprocessing
import string
import time
from multiprocessing import Manager

from LibUtils.SingletonInstane import SingletonInstane
from MuntiProcess.PubSubTest import subscribeProcess2, publishProcess
from MuntiProcess.abProcess import   abProcess
from MuntiProcess.cSequenceNumber import cSequenceNumberMultiProcessor
from ThreadUtils.abThread import abThread
from queue import Queue




class  cProcessingDTO:

    def __init__(self,_process,_abprocess:abProcess):
        self.processing_process=_process
        self.abprocess=_abprocess
    def GetProcessingProcess(self):
        return self.processing_process
    def GetProcess(self):
        return self.abprocess



## INFO

# class cMultiProcesser(abThread, SingletonInstane):
class cMultiProcesser(abThread):
    # seqGenerator = cSequenceNumberMultiProcessor()

    # def __init__(self , _process_size=0 ):
    #     super().__init__()
    #
    #     self.processReadyQueue = Queue()
    #     self.processingList = []
    #
    #     if _process_size == 0:
    #         self.process_size = math.ceil(multiprocessing.cpu_count() * 2.5)
    #     else:
    #         self.process_size = _process_size
    #
    #     self.lock = multiprocessing.Lock()
    #
    #     self.shardQueue = Manager().dict()
    #     self.shardQueuelock = multiprocessing.Lock()

    #
    # def __init__(self , _process_size=0):
    #     self.Init(_process_size)

    def __init__(self,_process_size=0):
        abThread.__init__(self)
        self.Init(_process_size)

    def Init(self, _process_size=0 ):
        self.processReadyQueue = Queue()
        # self.processingList = Manager().list()
        self.processingList = []

        if _process_size == 0:
            self.process_size = math.ceil(multiprocessing.cpu_count() * 2.5)
        else:
            self.process_size = _process_size

        # self.process_size=_process_size
        self.lock = multiprocessing.Lock()

        self.shardQueue = Manager().dict()
        self.shardQueuelock = multiprocessing.Lock()


        self.shardQueueEx = Manager().dict()
        self.shardQueueExlock = multiprocessing.Lock()


        return self


    def Append(self, process:abProcess):
        with self.lock:
            process._setSharedQueue(self.shardQueue, self.shardQueuelock)
            self.processReadyQueue.put( process )

    def AssineShardQueueEx(self, process:abProcess):
        with self.lock:
            process._assineSharedQueueEx(self.shardQueueEx, self.shardQueueExlock)

    def _getShardQueue(self , process:abProcess):
        return self.shardQueue[process.GetName()]

    def _getShardQueueEx(self , shared_queue_nm:string):
        return self.shardQueueEx[shared_queue_nm]

    def _allocateShardQueueEx(self ,shared_queue_nm:string ):
        self.shardQueueEx[shared_queue_nm]=[]
        return self.shardQueueEx[shared_queue_nm]


    def _allocateShardQueue(self ,process:abProcess ):
        self.shardQueue[process.GetName()]=[]
        return self.shardQueue[process.GetName()]



    def _deleteShardQueue(self,process:abProcess):
        del self.shardQueue[process.GetName()]


    def RunAsync(self):
        # self.Start()
        self.Start()
        # abThread.Start(self)

    def Action(self):
        self.Run()

    def Run(self):
        while True:

            if self.IsStop() :
                print("thread Stoped!! force Stop!!")
                return

            with self.lock:

                if self.processReadyQueue.empty() and len(self.processingList) == 0:
                    print("empty work")
                    return

            # allocation process
            with self.lock:

                processingStartQueue = []
                while not self.processReadyQueue.empty() and len(self.processingList) < self.process_size:
                    process = self.processReadyQueue.get()

                    self._allocateShardQueue(process)

                    processing = multiprocessing.Process(target=process.Action, args=(process,))
                    # processing.start()
                    processingStartQueue.append(processing)
                    self.processingList.append( cProcessingDTO( processing , process ) )
                    print("nwe release---------- " + process.GetName())
                    # print("a")
                while processingStartQueue:
                    prc=processingStartQueue.pop(0)
                    prc.start()
                    # print("new start---------- " + prc.name)

            # deallocation process
            with self.lock:
                for i in range(len(self.processingList)):
                    running_process = self.processingList[i].GetProcessingProcess()
                    # if running_process.getRunning() == False:
                    running_process.join(timeout=0.3)
                    if not running_process.is_alive():
                        self._deleteShardQueue( self.processingList[i].GetProcess() )
                        self.processingList.pop(i)
                    break

def main2():

    q=Queue()


    q.put("1")
    q.put("2")
    q.put("3")
    q.put("4")

    while not q.empty():
        item = q.get()
        print(item)  # 혹은 다른 처리를 수행


    b=[]
    b.append("1")
    b.append("2")
    b.append("3")
    b.append("4")

    while b:
        prc = b.pop(0)
        print(prc)




    pass

def main():

    # mp=cMultiProcesser(2)
    #
    # mp.Append( abProcess("abProcess_1") )
    # mp.Append( exProcess("exProcess_1") )
    # mp.Append( abProcess("abProcess_2") )
    # mp.Append( exProcess("exProcess_2") )
    # mp.Append( abProcess("abProcess_3") )

    # mp = cMultiProcesser(3)

    # mp = cMultiProcesser.instance(3).Append(  )

    mp= cMultiProcesser(3)
    # mp.Init(3)

    mp.Append(publishProcess("pub1"))
    mp.Append(subscribeProcess2("sub1"))
    mp.Append(subscribeProcess2("sub2"))

    print(mp.IsRunning())
    mp.RunAsync()
    print(mp.IsRunning())
    while True:
        if mp.IsRunning() == False:
            print("Stoped!!")
            break
        time.sleep(1)

    #
    # mp = cMultiProcesser(3)
    #
    # mp.Append(publishProcess("pub1"))
    # mp.Append(subscribeProcess2("sub1"))
    # mp.Append(subscribeProcess2("sub2"))
    #
    # print(mp.IsRunning())
    # # mp.Run()
    # mp.RunAsync()
    # print(mp.IsRunning())
    #
    # while True:
    #     if mp.IsRunning() == False:
    #         print("Stoped!!")
    #         break
    #     time.sleep(1)


if __name__ == '__main__':
    main()





