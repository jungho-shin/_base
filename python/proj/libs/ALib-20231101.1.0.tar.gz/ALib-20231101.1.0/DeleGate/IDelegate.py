from abc import ABC, abstractmethod
from typing import TypeVar, Generic


class IDelegate(ABC):
    pass


T1 = TypeVar('T1')
T2 = TypeVar('T2')
T3 = TypeVar('T3')
T4 = TypeVar('T4')
T5 = TypeVar('T5')
T6 = TypeVar('T6')
R = TypeVar('R')


class Action(IDelegate):
    @abstractmethod
    def invork(self):
        pass


class Action1(IDelegate, Generic[T1]):
    @abstractmethod
    def invork(self, t1: T1):
        pass


class Func(IDelegate, Generic[R]):
    @abstractmethod
    def invork(self) -> R:
        pass


class Func1(IDelegate, Generic[T1, R]):
    @abstractmethod
    def invork(self, t1: T1) -> R:
        pass

class MyFunc1(Func1[int, str]):
    def invork(self, t1: int) -> str:
        print(t1)
        return str(t1)

class cActTest:

    def __init__(self , _lamda):
        self.lamda=_lamda

    def proc(self):
        return self.lamda(10,20)

## NOTE
## Recommended to use lambda instead of deligate

#import redis
#
# connect_redis = lambda host, port: redis.Redis(host=host, port=port)
# # 사용 예시:
# connection = connect_redis('localhost', 6379)

def main():

    # my_func = MyFunc1()
    # print(my_func.invork(123))  # "123"

    vv = cActTest( lambda x , y : x+y )
    print( vv.proc())

    # vv = cActTest(MyFunc1()  )
    # vv.proc()

    pass


if __name__ == '__main__':
    main()
