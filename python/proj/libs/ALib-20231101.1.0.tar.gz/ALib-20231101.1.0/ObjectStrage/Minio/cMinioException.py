COMMON = "[ERROR] "
BUCKET_NOT_EXIST_ERROR = "Bucket Is Not Exist, Please Check Bucket Name."

MINIO_FILE_UPLOAD_ERROR = "When File Uploading. Unknown Error Occured."
MINIO_FOLDER_UPLOAD_ERROR = "When Folder Uploading. Unknown Error Occured."

MINIO_FILE_DOWNLOAD_ERROR = "When File Downloading. Unknown Error Occured."
MINIO_FOLDER_DOWNLOAD_ERROR = "When Folder Downloading. Unknown Error Occured."

MINIO_FILE_REMOVE_ERROR = "When File Removing. Unknown Error Occured."
MINIO_FOLDER_REMOVE_ERROR = "When Folder Removing. Unknown Error Occured."

INVALID_FILE_PATH_ERROR = "Invalid File Path, Please Check File Path."


class abCustomException(Exception):
    def __init__(self, _message):
        self.message = _message

    def __str__(self):
        return self.message


class FileInfoException(abCustomException):
    def __init__(self, _message):
        super(FileInfoException, self).__init__(_message)

    def __str__(self):
        super(FileInfoException, self).__str__()
