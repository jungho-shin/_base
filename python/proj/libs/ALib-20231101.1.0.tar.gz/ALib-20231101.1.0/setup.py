import setuptools

setuptools.setup(
	name='ALib',
	version='20231101.1.0',
	description='ALib',
	author='swm',
	author_email='None',
	url='None',
	packages=['Alarm', 'Codec', 'Collections', 'Configure', 'DbMgr', 'DeleGate', 'Exception', 'Geo', 'JSon', 'LibUtils', 'Log', 'Math', 'MuntiProcess', 'ObjectStrage', 'PCap', 'Processing', 'RestCall', 'Security', 'TestCode', 'ThreadUtils', 'TimeUtils', 'DbMgr.Example', 'ObjectStrage.Minio', 'ObjectStrage.Minio.api'],
	install_requires=['APScheduler==3.10.0', 'attrs==23.1.0', 'certifi==2023.5.7', 'haversine==2.7.0', 'jsonpickle==3.0.2', 'minio==7.1.15', 'numpy==1.24.2', 'psycopg2-binary==2.9.7', 'pyignite==0.6.1', 'PyMySQL==1.0.2', 'python-dateutil==2.8.2', 'pytz==2022.7.1', 'pytz-deprecation-shim==0.1.0.post0', 'scapy==2.5.0', 'shapely==2.0.1', 'six==1.16.0', 'tzdata==2022.7', 'tzlocal==4.2', 'urllib3==1.26.14']
)