from DbMgr.Example.cDB_Test import E_DB_ALIAS
from DbMgr.IDB_Lists import IDB_Lists
from DbMgr.cDBManager import cDBManager
from DbMgr.cDBProperty import cMysqlProperty, cIgniteProperty

from DbMgr.cIgniteDBOBJ import cIgniteOBOBJ
from DbMgr.cMysqlDBOBJ import cMysqlDBOBJ

class cDB_Info_Test( IDB_Lists ):
    def __init__(self):
        IDB_Lists.__init__(self ,
                           {
                               E_DB_ALIAS.MY_TEST: cMysqlDBOBJ(
                                   cMysqlProperty( host='192.168.1.79', port=3306 , user='oracle', passwd='oracle', db='SYSTEM_CONTROLLER_TEST' )) ,
                               E_DB_ALIAS.IGN_TEST: cIgniteOBOBJ(
                                   cIgniteProperty("192.168.1.79", 11211, _schema="PUBLIC"))
                           })

def main22():
    DBM = cDBManager(cDB_Info_Test())

    # host='90.90.30.245', port=3306 , user='tsr', passwd='tsr_12345', db='tsr'

    # cDBManager.__call__().Test_Print()
    # DBM.SetDBInfo(  )
    # cDBManager.__call__().Connect( E_DB_ALIAS.ORA_TEST )

    DBObj = DBM.GetDbObject(E_DB_ALIAS.MY_TEST)
    DBObj.Connect()
    # DBM.Connect( E_DB_ALIAS.ORA_TEST )
    # cDBManager.ConnectAll()

    results = DBObj.ExecuteQuery("select 'kim' as nm , 30 as age ")

    # for row in resilts.datas:
    #     print(row)

    # for row in resilts.datas:
    #     print( row[ resilts.getFieldID("nm") ] )
    #

    while results.next():
        print( results.getRow() )
        print( results.getValue(0) , results.getValue(1) )
        print( results.getValueByName("nm") , results.getValueByName("age") )
        pass

    pass

def main():

    DBM = cDBManager(cDB_Info_Test())

    # host='90.90.30.245', port=3306 , user='tsr', passwd='tsr_12345', db='tsr'

    # cDBManager.__call__().Test_Print()
    # DBM.SetDBInfo(  )
    #cDBManager.__call__().Connect( E_DB_ALIAS.ORA_TEST )

    DBObj = DBM.GetDbObject(E_DB_ALIAS.MY_TEST )
    DBObj.Connect()
    # DBM.Connect( E_DB_ALIAS.ORA_TEST )
    # cDBManager.ConnectAll()

    cur = DBObj.ExecuteQuery("select 'kim' as nm , 30 as age ")

    a=10
    a=100

    # print(DBObj.ExecuteQuery("select 'kim' as nm" ))



if __name__ == '__main__':
    main22()
