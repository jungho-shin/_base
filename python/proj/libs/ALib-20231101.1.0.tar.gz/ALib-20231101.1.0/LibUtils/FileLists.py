import os, platform
import time
import timeit
from enum import Enum
from typing import List
from pathlib import Path

from Exception.ExceptionType import ExceptionType

WINDOWS_PATH = "\\"
LINUX_PATH = "/"


class DepthType(Enum):
    DEPTH_DEFAULT = -1  # ALL DEPTH
    DEPTH_ZERO = 0
    DEPTH_ONE = 1


class OS(Enum):
    WINDOWS = "Windows"
    LINUX = "Linux"
    MACOS = "Darwin"


class FileLists:
    def __init__(self, _path, _depth=DepthType.DEPTH_DEFAULT.value):
        self.path = _path
        self.files = self.__getFileList()

    def getFiles(self):
        return self.files

    def getFilesCount(self):
        return len(self.files)

    def __getFileList(self):
        fileList = []
        for root, dirs, files in os.walk(self.path):
            if files:
                for file in files:

                    fileList.append([os.path.join(os.path.normpath(root), ""), file])
                    # fileList.append((os.path.join(root, "").replace("\\\\", "\\"), file))

        return fileList


    @staticmethod
    def makeCorrectFolderRoute(path):
        return os.path.join(os.path.normpath(path), "")


    @staticmethod
    def makeCorrectFileRoute(path):
        return os.path.join(os.path.normpath(path))

def main3():
    a = FileLists(r"C:\\Users\\swmai\\Desktop\\pcap")
    # print(FileLists.makeCorrectRoute(r"C:\\Users\\swmai\\Desktop\\pcap"))
    fl=a.getFiles()

    for f in fl:
        print(f)



if __name__ == '__main__':
    main3()
    # print(FileLists.makeCorrectRoute(r"C:\\\\Users\\\\swmai\\\\Desktop\\\\swm\\\\python\\\\infra-glue-python-template\\\\config\\\\config.conf"))
    # print(FileLists.makeCorrectRoute(r"C:\\Users\\swmai\\Desktop\\swm\\python\\infra-glue-python-template\\config"))
