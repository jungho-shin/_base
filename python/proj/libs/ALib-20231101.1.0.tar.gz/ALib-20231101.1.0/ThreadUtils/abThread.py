import threading
from abc import abstractmethod
from enum import Enum


class abThread ( threading.Thread ):
    class E_THREAD_STATUS(Enum):
        WAITING = 0
        RUNNING = 1
        STOPING = 2
    def __init__(self  ):
        super( abThread , self ).__init__()
        self._stop = threading.Event()
        self.thread_status=abThread.E_THREAD_STATUS.WAITING
    def setThreadStatus(self , _status ):
        self.thread_status=_status
    def GetThreadStatus(self):
        return self.thread_status
    def Stop(self):
        self._stop.set()
        self.setThreadStatus(abThread.E_THREAD_STATUS.STOPING)
    def IsStop(self):
        return self._stop.isSet()
    def IsRunning(self):
        return not self.IsStop()
    def Start(self):
        self.start()
        self._stop.clear()
        self.setThreadStatus(abThread.E_THREAD_STATUS.RUNNING)
    def run(self):
        self.Action()
        self.Stop()

    @abstractmethod
    def Action(self):
        print("abThread ")
        pass

